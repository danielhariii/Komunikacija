# Komunikacija
